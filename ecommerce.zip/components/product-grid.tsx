import Link from "next/link"
import Image from "next/image"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ShoppingCart } from "lucide-react"

// Mock product data
const products = [
  {
    id: 1,
    name: "Classic White T-Shirt",
    price: 29.99,
    image: "/placeholder.svg?height=400&width=400",
    category: "Clothing",
    isNew: true,
    isSale: false,
  },
  {
    id: 2,
    name: "Leather Crossbody Bag",
    price: 89.99,
    image: "/placeholder.svg?height=400&width=400",
    category: "Accessories",
    isNew: false,
    isSale: true,
    salePrice: 69.99,
  },
  {
    id: 3,
    name: "Minimalist Watch",
    price: 129.99,
    image: "/placeholder.svg?height=400&width=400",
    category: "Accessories",
    isNew: false,
    isSale: false,
  },
  {
    id: 4,
    name: "Denim Jacket",
    price: 79.99,
    image: "/placeholder.svg?height=400&width=400",
    category: "Clothing",
    isNew: true,
    isSale: false,
  },
  {
    id: 5,
    name: "Canvas Sneakers",
    price: 59.99,
    image: "/placeholder.svg?height=400&width=400",
    category: "Footwear",
    isNew: false,
    isSale: true,
    salePrice: 49.99,
  },
  {
    id: 6,
    name: "Ceramic Plant Pot",
    price: 24.99,
    image: "/placeholder.svg?height=400&width=400",
    category: "Home Goods",
    isNew: false,
    isSale: false,
  },
  {
    id: 7,
    name: "Wool Beanie",
    price: 19.99,
    image: "/placeholder.svg?height=400&width=400",
    category: "Accessories",
    isNew: false,
    isSale: false,
  },
  {
    id: 8,
    name: "Linen Shirt",
    price: 49.99,
    image: "/placeholder.svg?height=400&width=400",
    category: "Clothing",
    isNew: true,
    isSale: false,
  },
]

export default function ProductGrid() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mt-8">
      {products.map((product) => (
        <div key={product.id} className="group relative">
          <div className="aspect-square overflow-hidden rounded-lg bg-gray-100 group-hover:opacity-75">
            <Image
              src={product.image || "/placeholder.svg"}
              alt={product.name}
              width={400}
              height={400}
              className="h-full w-full object-cover object-center"
            />
            <div className="absolute top-2 left-2 flex flex-col gap-1">
              {product.isNew && <Badge className="bg-primary hover:bg-primary">New</Badge>}
              {product.isSale && <Badge variant="destructive">Sale</Badge>}
            </div>
          </div>
          <div className="mt-4 flex justify-between">
            <div>
              <h3 className="text-sm font-medium">
                <Link href={`/products/${product.id}`}>
                  <span aria-hidden="true" className="absolute inset-0" />
                  {product.name}
                </Link>
              </h3>
              <p className="mt-1 text-sm text-muted-foreground">{product.category}</p>
            </div>
            <div className="text-sm font-medium">
              {product.isSale ? (
                <div className="flex flex-col items-end">
                  <span className="line-through text-muted-foreground">${product.price}</span>
                  <span className="text-destructive">${product.salePrice}</span>
                </div>
              ) : (
                <span>${product.price}</span>
              )}
            </div>
          </div>
          <div className="mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button size="sm" className="w-full gap-1">
              <ShoppingCart className="h-4 w-4" />
              Add to Cart
            </Button>
          </div>
        </div>
      ))}
    </div>
  )
}

