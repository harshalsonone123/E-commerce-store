import Link from "next/link"
import Image from "next/image"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ShoppingCart } from "lucide-react"

// Mock featured product data
const featuredProducts = [
  {
    id: 1,
    name: "Premium Leather Backpack",
    price: 149.99,
    image: "/placeholder.svg?height=400&width=400",
    category: "Accessories",
    isNew: true,
    isSale: false,
    description: "Handcrafted from premium leather with ample storage for all your essentials.",
  },
  {
    id: 2,
    name: "Wireless Noise-Cancelling Headphones",
    price: 199.99,
    image: "/placeholder.svg?height=400&width=400",
    category: "Electronics",
    isNew: false,
    isSale: true,
    salePrice: 159.99,
    description: "Immersive sound quality with active noise cancellation for the perfect listening experience.",
  },
  {
    id: 3,
    name: "Organic Cotton Sweater",
    price: 89.99,
    image: "/placeholder.svg?height=400&width=400",
    category: "Clothing",
    isNew: true,
    isSale: false,
    description: "Soft, sustainable, and stylish. Perfect for layering in any season.",
  },
]

export default function FeaturedProducts() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-8">
      {featuredProducts.map((product) => (
        <div key={product.id} className="group relative flex flex-col">
          <div className="aspect-square overflow-hidden rounded-lg bg-gray-100 group-hover:opacity-75">
            <Image
              src={product.image || "/placeholder.svg"}
              alt={product.name}
              width={400}
              height={400}
              className="h-full w-full object-cover object-center"
            />
            <div className="absolute top-2 left-2 flex flex-col gap-1">
              {product.isNew && <Badge className="bg-primary hover:bg-primary">New</Badge>}
              {product.isSale && <Badge variant="destructive">Sale</Badge>}
            </div>
          </div>
          <div className="mt-4 flex-1">
            <h3 className="text-lg font-medium">
              <Link href={`/products/${product.id}`}>
                <span aria-hidden="true" className="absolute inset-0" />
                {product.name}
              </Link>
            </h3>
            <p className="mt-1 text-sm text-muted-foreground">{product.category}</p>
            <p className="mt-2 text-sm text-muted-foreground line-clamp-2">{product.description}</p>
          </div>
          <div className="mt-4 flex justify-between items-center">
            <div className="text-lg font-medium">
              {product.isSale ? (
                <div className="flex items-center gap-2">
                  <span className="line-through text-muted-foreground text-sm">${product.price}</span>
                  <span className="text-destructive">${product.salePrice}</span>
                </div>
              ) : (
                <span>${product.price}</span>
              )}
            </div>
            <Button size="sm" className="gap-1">
              <ShoppingCart className="h-4 w-4" />
              Add to Cart
            </Button>
          </div>
        </div>
      ))}
    </div>
  )
}

