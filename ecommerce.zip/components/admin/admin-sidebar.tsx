import Link from "next/link"
import { BarChart3, Home, Package, Settings, ShoppingCart, Tag, Users } from "lucide-react"

export function AdminSidebar() {
  return (
    <div className="w-64 h-full border-r bg-muted/40 py-6 px-3">
      <div className="space-y-4">
        <div className="px-3 py-2">
          <h2 className="mb-2 px-4 text-lg font-semibold">Dashboard</h2>
          <div className="space-y-1">
            <Link
              href="/admin"
              className="flex items-center rounded-md px-3 py-2 text-sm font-medium bg-primary text-primary-foreground"
            >
              <Home className="mr-2 h-4 w-4" />
              Overview
            </Link>
            <Link
              href="/admin/analytics"
              className="flex items-center rounded-md px-3 py-2 text-sm font-medium hover:bg-muted"
            >
              <BarChart3 className="mr-2 h-4 w-4" />
              Analytics
            </Link>
          </div>
        </div>
        <div className="px-3 py-2">
          <h2 className="mb-2 px-4 text-lg font-semibold">Store Management</h2>
          <div className="space-y-1">
            <Link
              href="/admin/products"
              className="flex items-center rounded-md px-3 py-2 text-sm font-medium hover:bg-muted"
            >
              <Package className="mr-2 h-4 w-4" />
              Products
            </Link>
            <Link
              href="/admin/orders"
              className="flex items-center rounded-md px-3 py-2 text-sm font-medium hover:bg-muted"
            >
              <ShoppingCart className="mr-2 h-4 w-4" />
              Orders
            </Link>
            <Link
              href="/admin/customers"
              className="flex items-center rounded-md px-3 py-2 text-sm font-medium hover:bg-muted"
            >
              <Users className="mr-2 h-4 w-4" />
              Customers
            </Link>
            <Link
              href="/admin/discounts"
              className="flex items-center rounded-md px-3 py-2 text-sm font-medium hover:bg-muted"
            >
              <Tag className="mr-2 h-4 w-4" />
              Discounts
            </Link>
          </div>
        </div>
        <div className="px-3 py-2">
          <h2 className="mb-2 px-4 text-lg font-semibold">Settings</h2>
          <div className="space-y-1">
            <Link
              href="/admin/settings"
              className="flex items-center rounded-md px-3 py-2 text-sm font-medium hover:bg-muted"
            >
              <Settings className="mr-2 h-4 w-4" />
              General
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

